package application;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.Event;

import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import static javafx.print.PrintColor.COLOR;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DataFormat;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TitledPane;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javax.imageio.ImageIO;

public class RootLayout extends AnchorPane {

    /**
     * @return the comandos
     */
    public ArrayList<Comando> getComandos() {
        return comandos;
    }

    public int getIndexComando(DraggableNode n) {
        for (Comando c : getComandos()) {
            if (c.getId() == n.getId()) {
                return comandos.indexOf(c);
            }
        }
        return 0;
    }

    public Comando getComando(DraggableNode n) {
        for (Comando c : getComandos()) {
            if (c.getId() == n.getId()) {
                return c;
            }
        }
        return null;
    }

    /**
     * @param comandos the comandos to set
     */
    public void setComandos(ArrayList<Comando> comandos) {
        this.comandos = comandos;
    }

    /**
     * @return the flag
     */
    public int getFlag() {
        return flag;
    }

    /**
     * @param flag the flag to set
     */
    public void setFlag(int flag) {
        this.flag = flag;
    }

    /**
     * @return the X_Cursor
     */
    public int getX_Cursor() {
        return X_Cursor;
    }

    /**
     * @param X_Cursor the X_Cursor to set
     */
    public void setX_Cursor(int X_Cursor) {
        this.X_Cursor = X_Cursor;
    }

    /**
     * @return the Y_Cursor
     */
    public int getY_Cursor() {
        return Y_Cursor;
    }

    /**
     * @param Y_Cursor the Y_Cursor to set
     */
    public void setY_Cursor(int Y_Cursor) {
        this.Y_Cursor = Y_Cursor;
    }

    @FXML
    SplitPane base_pane;
    @FXML
    AnchorPane right_pane;
    @FXML
    AnchorPane structure_pane;
    @FXML
    VBox left_pane;
    @FXML
    ScrollPane scroll_pane;

    @FXML
    TextField id;
    @FXML
    TextField tipo;
    @FXML
    Button geraCodigo;
    @FXML
    Button run;
    @FXML
    ImageView lixeira;
    @FXML
    TitledPane menuInput;
    @FXML
    TitledPane menuAtribuicao;
    @FXML
    TitledPane menuIf;
    @FXML
    TitledPane menuIf_Else;
    @FXML
    TitledPane menuLoop;
    @FXML
    TitledPane menuOutput;

    @FXML
    TextField inputNome;
    @FXML
    ComboBox inputTipo;
    @FXML
    TextField inputValor;
    @FXML
    Button inputValidar;

    @FXML
    ComboBox Atr_Var;
    @FXML
    TextField Atr_Expression;
    @FXML
    Button atrValidar;

    @FXML
    TextField ifExpression;
    @FXML
    Button ifValidar;

    @FXML
    TextField ifElseExpression;
    @FXML
    Button ifElseValidar;

    @FXML
    TextField outputVar;
    @FXML
    TextField outputTexto;
    @FXML
    Button outputValidar;

    @FXML
    ComboBox loopChoice;

    @FXML
    TabPane loopTab;

    @FXML
    Tab tabFor;
    @FXML
    ComboBox varFor;
    @FXML
    TextField from;
    @FXML
    TextField to;
    @FXML
    TextField step;

    @FXML
    Tab tabWhile;
    @FXML
    TextField whileExpression;

    @FXML
    Button loopValidar;

    @FXML
    AnchorPane lixeiraPane;

    ArrayList<Rectangle> estruturas;

    private ArrayList<Comando> comandos;

    private ArrayList<Comando> commandList;
    private ArrayList<Comando> elseList;

    Comando source, alvo, source_parent, alvo_parent;
    ArrayList<Comando> lista_origem, lista_alvo = new ArrayList<Comando>();
    int indice_origem, indice_alvo = 0;

    int if_flag = 1, else_flag = 1;

    public Comando command;

    private EventHandler<DragEvent> mTrashDragOver;
    private EventHandler<DragEvent> mTrashDragDropped;

    private int flag = 0;
    int X_Cursor = 182;
    public int Y_Cursor = 75;

    int counter = 0;

    int cabecalho = 1;

    StackPane centeredPane = new StackPane();

    public Point2dSerial coordenada = new Point2dSerial(X_Cursor, Y_Cursor);

    public int Width = 25, Height = 25;

    boolean collision;

    boolean key = false;

    int position;

    int checagem = 0;

    public ImageView trash;

    public Comando parent = null;

    private DragIcon mDragOverIcon = null;

    private EventHandler<DragEvent> mDragTrash = null;

    public String idAtualiza;

    private EventHandler<DragEvent> mIconDragOverRoot = null;
    private EventHandler<DragEvent> mIconDragDropped = null;
    private EventHandler<DragEvent> mIconDragOverRightPane = null;

    ObservableMap<String, List<String>> runMap = FXCollections.observableHashMap();
    ObservableMap<String, String> auxMap = FXCollections.observableHashMap();
    //HashMap<String, List<String>> runMap = new HashMap<String, List<String>>();
    HashMap<String, List<String>> compilerMap = new HashMap<String, List<String>>();

    public RootLayout() {

        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/RootLayout.fxml")
        );

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();

        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

    }

    @FXML
    private void initialize() {

        //Add one icon that will be used for the drag-drop process
        //This is added as a child to the root anchorpane so it can be visible
        //on both sides of the split pane.
        mDragOverIcon = new DragIcon();

        mDragOverIcon.setVisible(false);
        mDragOverIcon.setOpacity(0.65);
        getChildren().add(mDragOverIcon);

        //populate left pane with multiple colored icons for testing
        for (int i = 0; i < 6; i++) {

            DragIcon icn = new DragIcon();

            addDragDetection(icn);

            icn.setType(DragIconType.values()[i]);
            left_pane.getChildren().add(icn);
        }

        setComandos(new ArrayList<Comando>());

        estruturas = new ArrayList<Rectangle>();

        Estrutura cabecalho = new Estrutura(structure_pane, estruturas, Color.NAVY, 50, 50, 500, 25, "cabecalho", null);
        Estrutura coluna = new Estrutura(structure_pane, estruturas, Color.NAVY, 50, 50, 25, 150, "coluna", null);
        Estrutura rodape = new Estrutura(structure_pane, estruturas, Color.NAVY, 50, 200, 500, 25, "rodape", null);

        right_pane.setBackground(Background.EMPTY);
        structure_pane.setBackground(Background.EMPTY);

        centeredPane.setPrefSize(80, 80);
        centeredPane.setLayoutX(650);
        centeredPane.setLayoutY(50);

        Image image = new Image("trash_can.png", 80, 80, false, false);
        lixeira = new ImageView(image);
        centeredPane.getChildren().add(lixeira);

        structure_pane.getChildren().add(centeredPane);

        buildDragHandlers();
        scrollHandler();
        inicializaMenus();

        geraCodigo.setOnMouseClicked((event) -> {
            try {
                geraCodigo();
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Erro de compilação");
                alert.setHeaderText(null);
                alert.setContentText("1 ou mais blocos ainda não foram validados!");
                alert.showAndWait();
            }
        });

        run.setOnMouseClicked((event) -> {
            auxMap.clear();
            runMap.clear();

            run(getComandos());

            for (Map.Entry<String, List<String>> entry : runMap.entrySet()) {
                String key = entry.getKey();
                List<String> values = entry.getValue();

                System.out.println("id: " + key + " - Nome: " + values.get(0) + "; Tipo: " + values.get(1) + "; Valor: " + values.get(2));
            }

            for (Map.Entry<String, String> entry : auxMap.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();

                System.out.println("nome: " + key + " - valor: " + value);
            }
        });

        inputValidar.setOnMouseClicked((event) -> {
            for (Comando d : getComandos()) {
                if (retornaComando(id.getText(), d) == null) {
                } else {
                    break;
                }
            }
            command.validar();
        });

        atrValidar.setOnMouseClicked((event) -> {
            for (Comando d : getComandos()) {
                if (retornaComando(id.getText(), d) == null) {
                } else {
                    break;
                }
            }
            command.validar();
            //retornaComando(id.getText(), getComandos()).validar();
            //System.out.println(retornaComando(id.getText()).getId());
        });

        loopChoice.valueProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue ov, String t, String t1) {
                if (loopChoice.getSelectionModel().getSelectedItem().toString().equalsIgnoreCase("for")) {
                    tabFor.setDisable(false);
                    loopTab.getSelectionModel().select(tabFor);
                    tabWhile.setDisable(true);
                } else {
                    tabFor.setDisable(true);
                    tabWhile.setDisable(false);
                    loopTab.getSelectionModel().select(tabWhile);
                }
            }
        });

        outputValidar.setOnMouseClicked((event) -> {
            for (Comando d : getComandos()) {
                if (retornaComando(id.getText(), d) == null) {
                } else {
                    break;
                }
            }
            command.validar();
            //System.out.println(retornaComando(id.getText()).getId());
        });

        ifValidar.setOnMouseClicked((event) -> {
            for (Comando d : getComandos()) {
                if (retornaComando(id.getText(), d) == null) {
                } else {
                    break;
                }
            }
            command.validar();
            //System.out.println(retornaComando(id.getText()).getId());
        });

        ifElseValidar.setOnMouseClicked((event) -> {
            for (Comando d : getComandos()) {
                if (retornaComando(id.getText(), d) == null) {
                } else {
                    break;
                }
            }
            command.validar();
            //System.out.println(retornaComando(id.getText()).getId());
        });

        loopValidar.setOnMouseClicked((event) -> {
            for (Comando d : getComandos()) {
                if (retornaComando(id.getText(), d) == null) {
                } else {
                    break;
                }
            }
            command.validar();
            //System.out.println(retornaComando(id.getText()).getId());
        });
    }

    public void geraCodigo() throws Exception {
        try {
            for (Comando c : getComandos()) {
                checkEvaluated(c);
            }

            if (checagem == 0) {
                codigoGerado codigoGerado = new codigoGerado(this);

                StringBuilder code = new StringBuilder();
                code.append("import java.io.*;\n");
                code.append("import java.util.*;\n");
                code.append("import javax.swing.JOptionPane;\n\n");
                code.append("public class Codigo {\n\n");
                code.append("public static void main(String[] args) {\n\n");
                //code.append("Scanner scan = new Scanner(System.in);\n\n");

                for (Comando c : getComandos()) {
                    codify(c, code);
                    code.append("\n");
                }

                code.append("}\n}\n");

                codigoGerado.areaCodigo.setText(code.toString());

            } else {
                throw new Exception();
            }
            //centeredPane.setLayoutY(centeredPane.getLayoutY() + 50);
            //System.out.println(lixeira.getBoundsInParent());
            //System.out.println(lixeira.getBoundsInLocal());
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Erro de compilação");
            alert.setHeaderText(null);
            alert.setContentText("1 ou mais blocos ainda não foram validados!");
            alert.showAndWait();
        }
    }

    public void codify(Comando comando, StringBuilder stringBuilder) {
        stringBuilder.append(comando.writeCode());
        if (comando.getList() == null) {
        } else {
            for (Comando child : comando.getList()) {
                stringBuilder.append("\n");
                codify(child, stringBuilder);
            }
            stringBuilder.append("\n}\n");
        }
    }

    public void inicializaMenus() {
        inputTipo.getItems().addAll("String", "Integer", "Double");
        loopChoice.getItems().addAll("for", "while");
        tabFor.setDisable(true);
        tabWhile.setDisable(true);
    }

    //ESTE MÉTODO POR ENQUANTO APENAS ESCREVE A POSIÇÃO DA BARRA VERTICAL DO SCROLL PANE
    public void scrollHandler() {
        scroll_pane.vvalueProperty().addListener(new ChangeListener<Number>() {
            public void changed(ObservableValue<? extends Number> ov,
                    Number old_val, Number new_val) {
                centeredPane.setTranslateY(new_val.doubleValue() * structure_pane.getHeight());
                //ensureVisible(scroll_pane, centeredPane);
                //System.out.println(new_val.doubleValue());
            }
        }
        );
    }

    public ArrayList<Comando> getList() {
        return getComandos();
    }

    private void addDragDetection(DragIcon dragIcon) {

        dragIcon.setOnDragDetected(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // set drag event handlers on their respective objects
                base_pane.setOnDragOver(mIconDragOverRoot);
                right_pane.setOnDragOver(mIconDragOverRightPane);
                right_pane.setOnDragDropped(mIconDragDropped);

                // get a reference to the clicked DragIcon object
                DragIcon icn = (DragIcon) event.getSource();

                //begin drag ops
                mDragOverIcon.setType(icn.getType());
                mDragOverIcon.relocateToPoint(new Point2D(event.getSceneX(), event.getSceneY()));

                ClipboardContent content = new ClipboardContent();
                DragContainer container = new DragContainer();

                container.addData("type", mDragOverIcon.getType().toString());
                content.put(DragContainer.AddNode, container);

                mDragOverIcon.startDragAndDrop(TransferMode.ANY).setContent(content);
                mDragOverIcon.setVisible(true);
                mDragOverIcon.setMouseTransparent(true);
                event.consume();
            }
        });
    }

    public void update() {
        right_pane.getChildren().clear();
        structure_pane.getChildren().removeAll(estruturas);
        estruturas.clear();

        double h = scroll_pane.getHvalue();
        double v = scroll_pane.getVvalue();

        scroll_pane.setVvalue(0.0);
        scroll_pane.setHvalue(0.0);

        for (Comando c : getComandos()) {
            coordenada = c.draw(coordenada.getX(), coordenada.getY());
            //Y_Cursor += 50;
        }

        scroll_pane.setVvalue(v);
        scroll_pane.setHvalue(h);

        for (Node n : right_pane.getChildren()) {
            n.setOpacity(1);
        }

        //Y_Cursor = 75;
        Estrutura cabecalho = new Estrutura(structure_pane, estruturas, Color.NAVY, 50, 50, 500, 25, "cabecalho", null);
        Estrutura coluna = new Estrutura(structure_pane, estruturas, Color.NAVY, 50, 50, 25, (int) (coordenada.getY() + 100), "coluna", null);
        Estrutura rodape = new Estrutura(structure_pane, estruturas, Color.NAVY, 50, (int) (coordenada.getY() + 150), 500, 25, "rodape", null);

        coordenada = new Point2dSerial(182, 75);

        if (getComandos().size() == 0) {
            position = 0;
        }

        //atualizaIndices(getComandos());
        for (Comando c : getComandos()) {
            showChildren(c);
        }

        menuInput.setDisable(true);
        menuAtribuicao.setDisable(true);
        menuIf.setDisable(true);
        menuIf_Else.setDisable(true);
        menuLoop.setDisable(true);
        menuOutput.setDisable(true);

        menuInput.setExpanded(false);
        menuAtribuicao.setExpanded(false);
        menuIf.setExpanded(false);
        menuIf_Else.setExpanded(false);
        menuLoop.setExpanded(false);
        menuOutput.setExpanded(false);

        id.setText("");
        tipo.setText("");
        //System.out.println();

        for (Map.Entry<String, List<String>> entry : runMap.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();

        }
    }

    public void atualizaIndices(ArrayList<Comando> List) {
        if (List.size() == 0) {
            position = 0;
        }
        for (Comando c : List) {
            if (c.getList() == null) {
            } else {
                if (c.getList().size() == 0) {
                    c.position = 0;
                } else {
                    atualizaIndices(c.getList());
                }
            }
        }
    }

    public static void showChildren(Comando comando) {
        int count = 0;
        //System.out.println("nó: " + comando.getType() + " - id: " + comando.getId());
        //System.out.println(comando.getType() + " " + comando.getId() + " " + comando.isElse + " " + comando.comandoAtrelado);
        if (comando.getList() == null) {
        } else {
            //System.out.println("filhos de " + comando.getType() + " - id " + comando.getId() + ": ");
            for (Comando child : comando.getList()) {
                // Now show the child's children.
                showChildren(child);
                count++;
            }
            //System.out.println("total de descendentes do nó " + comando.getType() + " - id " + comando.getId() + ": " + count);
        }
    }

    public void checkEvaluated(Comando comando) {
        if (comando.evaluated = false) {
            checagem++;
        }
        if (comando.getList() == null) {
        } else {
            for (Comando child : comando.getList()) {
                checkEvaluated(child);
            }
        }
    }

    public void run(ArrayList<Comando> comandos) {
        for (Comando c : comandos) {
            c.run();
            /*if (c.getList() == null) {

            } else {
                run(c.getList());
            }*/
        }
    }

    public void atualizaValor(String nome, String valor) {
        System.out.println(valor);
        for (Entry<String, List<String>> entry : runMap.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();
            if (values.get(0).equals(nome)) {
                idAtualiza = key;
                values.set(2, valor);
                break;
            }
            //System.out.println("id: " + key + " - Nome: " + values.get(0) + "; Tipo: " + values.get(1) + "; Valor: " + values.get(2));
        }

        for (Comando d : getComandos()) {
            if (retornaComando(idAtualiza, d) == null) {
            } else {
                command.setValor(valor);
                //System.out.println(command.getId());
                break;
            }
        }

        //System.out.println(command.getId() + " - " + command.getValor());
    }

    public Comando retornaValor(String nome, Comando comando) {
        if (comando.getNome().matches(nome)) {
            command = comando;
            return comando;
        } else {
            if (comando.getList() == null) {
            } else {
                for (Comando child : comando.getList()) {
                    retornaValor(nome, child);
                }
            }
        }
        return null;
    }

    public Comando retornaComando(String id, Comando comando) {
        if (comando.getId().matches(id)) {
            command = comando;
            return comando;
        } else {
            if (comando.getList() == null) {
            } else {
                for (Comando child : comando.getList()) {
                    retornaComando(id, child);
                }
            }
        }
        return null;
    }

    public Comando findComando(String Id, Comando comando) {
        if (comando.getId().matches(Id)) {
            parent = comando;
            //System.out.println("Encontrado o comando " + comando.getType() + " - id: " + comando.getId());
            if (cabecalho == 1) {
                parent.position = 0;
            } else if (cabecalho == 0) {
                parent.position = parent.getList().size();
            } else {

            }
            cabecalho = 1;
            return comando;
        } else {
            if (comando.getList() == null) {
                //System.out.println("O comando " + comando.getType() + " - id: " + comando.getId() + " possui lista vazia");
            } else {
                for (Comando child : comando.getList()) {
                    findComando(Id, child);
                }
            }
        }
        return null;
    }

    public Comando findParent(String Id, Comando comando) {
        if (comando.getId().matches(Id)) {
            if (comando.getParent() != null) {
                parent = comando.getParent();
                parent.position = parent.getList().indexOf(comando);
                //comando.getParent().position = comando.getParent().getList().indexOf(comando);
            }
            return comando.getParent();
        } else {
            if (comando.getList() == null) {
            } else {
                for (Comando child : comando.getList()) {
                    findParent(Id, child);
                }
            }
        }
        return null;
    }

    public void insereComando(Comando comando) {
        if (parent == null) {
            comando.setParent(null);
            getComandos().add(position, comando);
            //position = 0;
            //parent = null;
        } else {
            //System.out.println("posição: " + parent.position);
            comando.setParent(parent);
            parent.getList().add(parent.position, comando);
            //System.out.println(parent + " " + parent.position);
            //position = 0;
            //parent = null;
        }
        if (comando.isElse == true) {
            comando.getNode().commandLine.setText("} else {");
            comando.evaluated = true;
        }

        setFlag(getFlag() + 1);
    }

    public void findComandoOrigem(String id, ArrayList<Comando> List) {
        for (Comando c : List) {
            if (c.getId().matches(id)) {
                if (c.getParent() == null) {
                    source = c;
                    source_parent = null;
                    lista_origem = getComandos();
                    indice_origem = getComandos().indexOf(c);
                    //System.out.println(source.getType() + " - parent: " + source_parent + " - indice: " + indice_origem);
                    break;
                } else {
                    source = c;
                    source_parent = c.getParent();
                    lista_origem = c.getParent().getList();
                    indice_origem = c.getParent().getList().indexOf(c);
                    //System.out.println(source.getType() + " - parent: " + source_parent.getId() + " - indice: " + indice_origem);
                    break;
                }
            } else {
                if (c.getList() == null) {

                } else {
                    findComandoOrigem(id, c.getList());
                }
            }
        }
    }

    public void findComandoDestino(String id, ArrayList<Comando> List) {
        for (Comando c : List) {
            if (c.getId().matches(id)) {
                if (c.getParent() == null) {
                    alvo = c;
                    alvo_parent = null;
                    lista_alvo = getComandos();
                    indice_alvo = getComandos().indexOf(c);
                    //if (indice_alvo == -1) indice_alvo = 0;
                    //if (indice_alvo == observer.getComandos().size()) indice_alvo--;
                    //System.out.println(alvo.getType() + " - parent: " + alvo_parent + " - indice: " + indice_alvo);
                    break;
                } else {
                    alvo = c;
                    alvo_parent = c.getParent();
                    lista_alvo = c.getParent().getList();
                    indice_alvo = c.getParent().getList().indexOf(c);
                    //if (indice_alvo == -1) indice_alvo = 0;
                    //if (indice_alvo == c.getParent().getList().size()) indice_alvo--;
                    //System.out.println(alvo.getType() + " - parent: " + alvo_parent.getId() + " - indice: " + indice_alvo);
                    break;
                }
            } else {
                if (c.getList() == null) {

                } else {
                    findComandoDestino(id, c.getList());
                }
            }
        }
    }

    public void changeComando() {
        if (source_parent == null && alvo_parent == null) {
            getComandos().remove(source);
            getComandos().add(getComandos().indexOf(alvo) + 1, source);
        } else {
            lista_origem.remove(source);

            String id = source.getId();

            for (Node n : right_pane.getChildren()) {
                if (n.getId().matches(id)) {
                    right_pane.getChildren().remove(n);
                    break;
                }
            }

            parent = alvo_parent;
            position = indice_alvo + 1;

            verificaTipo(source.getNode(), source.comandoAtrelado, source.isElse);
        }
        update();
    }

    public void changeComando2() {
        for (Comando d : getComandos()) {
            if (retornaComando(command.comandoAtrelado, d) == null) {
            } else {
                break;
            }
        }

        source = command;

        if (source_parent == null && alvo_parent == null) {
            getComandos().remove(source);
            getComandos().add(getComandos().indexOf(alvo) + 1, source);
        } else {
            lista_origem.remove(source);

            String id = source.getId();

            for (Node n : right_pane.getChildren()) {
                if (n.getId().matches(id)) {
                    right_pane.getChildren().remove(n);
                    break;
                }
            }

            parent = alvo_parent;
            position = indice_alvo + 1;

            verificaTipo(source.getNode(), source.comandoAtrelado, source.isElse);
        }
        update();
    }

    public void recolheMenus() {
        menuInput.setExpanded(false);
        menuAtribuicao.setExpanded(false);
        menuIf.setExpanded(false);
        menuIf_Else.setExpanded(false);
        menuLoop.setExpanded(false);
        menuOutput.setExpanded(false);
    }

    public void habilitaMenu(DraggableNode node) {
        switch (node.mType) {
            case input:
                menuInput.setDisable(false);
                menuAtribuicao.setDisable(true);
                menuIf.setDisable(true);
                menuIf_Else.setDisable(true);
                menuLoop.setDisable(true);
                menuOutput.setDisable(true);
                recolheMenus();
                break;
            case atrArithInput:
                menuInput.setDisable(true);
                menuAtribuicao.setDisable(false);
                menuIf.setDisable(true);
                menuIf_Else.setDisable(true);
                menuLoop.setDisable(true);
                menuOutput.setDisable(true);
                recolheMenus();
                break;
            case condition:
                menuInput.setDisable(true);
                menuAtribuicao.setDisable(true);
                menuIf.setDisable(false);
                menuIf_Else.setDisable(true);
                menuLoop.setDisable(true);
                menuOutput.setDisable(true);
                recolheMenus();
                break;
            case elsee:
                for (Comando d : getComandos()) {
                    if (retornaComando(node.getId(), d) == null) {
                    } else {
                        break;
                    }
                }

                if (command.isElse == false) {
                    menuInput.setDisable(true);
                    menuAtribuicao.setDisable(true);
                    menuIf.setDisable(true);
                    menuIf_Else.setDisable(false);
                    menuLoop.setDisable(true);
                    menuOutput.setDisable(true);
                    recolheMenus();
                } else {
                    menuInput.setDisable(true);
                    menuAtribuicao.setDisable(true);
                    menuIf.setDisable(true);
                    menuIf_Else.setDisable(true);
                    menuLoop.setDisable(true);
                    menuOutput.setDisable(true);
                    recolheMenus();
                }
                break;
            case loop:
                menuInput.setDisable(true);
                menuAtribuicao.setDisable(true);
                menuIf.setDisable(true);
                menuIf_Else.setDisable(true);
                menuLoop.setDisable(false);
                menuOutput.setDisable(true);
                recolheMenus();
                break;
            case output:
                menuInput.setDisable(true);
                menuAtribuicao.setDisable(true);
                menuIf.setDisable(true);
                menuIf_Else.setDisable(true);
                menuLoop.setDisable(true);
                menuOutput.setDisable(false);
                recolheMenus();
                break;
            default:
                menuInput.setDisable(true);
                menuAtribuicao.setDisable(true);
                menuIf.setDisable(true);
                menuIf_Else.setDisable(true);
                menuLoop.setDisable(true);
                menuOutput.setDisable(true);
                recolheMenus();
                break;
        }
    }

    public void verificaTipo(DraggableNode node, String comandoAtrelado, boolean isElse) {
        switch (node.mType) {
            case input:
                ComandoAlocVar input = new ComandoAlocVar(right_pane, node, this, comandoAtrelado, isElse);
                insereComando(input);
                break;
            case atrArithInput:
                ComandoAtrArithInput var_const = new ComandoAtrArithInput(right_pane, node, this, comandoAtrelado, isElse);
                insereComando(var_const);
                break;
            case condition:
                ComandoIf condition = new ComandoIf(right_pane, node, this, comandoAtrelado, isElse);
                insereComando(condition);
                condition.setList(new ArrayList<Comando>());
                //System.out.println(condition.getList());
                break;
            case elsee:
                ComandoIfElse elsee = new ComandoIfElse(right_pane, node, this, comandoAtrelado, isElse);
                insereComando(elsee);
                elsee.setList(new ArrayList<Comando>());
                break;
            case loop:
                ComandoLoop loop = new ComandoLoop(right_pane, node, this, comandoAtrelado, isElse);
                insereComando(loop);
                loop.setList(new ArrayList<Comando>());
                break;
            case output:
                ComandoOutput output = new ComandoOutput(right_pane, node, this, comandoAtrelado, isElse);
                insereComando(output);
                break;
            default:
                break;
        }
    }

    private void buildDragHandlers() {

        //drag over transition to move widget form left pane to right pane
        mIconDragOverRoot = new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {

                Point2D p = right_pane.sceneToLocal(event.getSceneX(), event.getSceneY());

                //turn on transfer mode and track in the right-pane's context 
                //if (and only if) the mouse cursor falls within the right pane's bounds.
                if (!right_pane.boundsInLocalProperty().get().contains(p)) {

                    event.acceptTransferModes(TransferMode.ANY);
                    mDragOverIcon.relocateToPoint(new Point2D(event.getSceneX(), event.getSceneY()));
                    return;
                }

                event.consume();
            }
        };

        mIconDragOverRightPane = new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {

                event.acceptTransferModes(TransferMode.ANY);

                //convert the mouse coordinates to scene coordinates,
                //then convert back to coordinates that are relative to 
                //the parent of mDragIcon.  Since mDragIcon is a child of the root
                //pane, coodinates must be in the root pane's coordinate system to work
                //properly.
                mDragOverIcon.relocateToPoint(
                        new Point2D(event.getSceneX(), event.getSceneY())
                );

                Bounds no = mDragOverIcon.localToScene(mDragOverIcon.getBoundsInLocal());
                //position = 0;

                for (Node n : right_pane.getChildren()) {
                    //target = (DraggableNode) n;
                    Bounds target;
                    target = n.localToScene(n.getBoundsInLocal());
                    if (no.intersects(target)) {
                        n.setOpacity(0.3);

                    } else {
                        n.setOpacity(1);
                    }
                }

                event.consume();
            }
        };

        mIconDragDropped = new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {

                DragContainer container
                        = (DragContainer) event.getDragboard().getContent(DragContainer.AddNode);

                container.addData("scene_coords",
                        new Point2D(event.getSceneX(), event.getSceneY()));

                ClipboardContent content = new ClipboardContent();
                content.put(DragContainer.AddNode, container);

                event.getDragboard().setContent(content);
                event.setDropCompleted(true);
            }
        };

        this.setOnDragDone(new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {

                right_pane.removeEventHandler(DragEvent.DRAG_OVER, mIconDragOverRightPane);
                right_pane.removeEventHandler(DragEvent.DRAG_DROPPED, mIconDragDropped);
                base_pane.removeEventHandler(DragEvent.DRAG_OVER, mIconDragOverRoot);

                Bounds no = mDragOverIcon.localToScene(mDragOverIcon.getBoundsInLocal());

                for (Node n : right_pane.getChildren()) {
                    //target = (DraggableNode) n;
                    Bounds target;
                    target = n.localToScene(n.getBoundsInLocal());
                    if (no.intersects(target)) {
                        if (n.getId().contains("cabecalho_")) {
                            cabecalho = 1;
                            String id = n.getId().substring(n.getId().indexOf("_") + 1);
                            //System.out.println(id);
                            for (Comando d : getComandos()) {
                                if (findComando(id, d) == null) {
                                } else {
                                    parent = d;
                                    parent.position = 0;
                                    break;
                                }
                            }
                        } else if (n.getId().contains("rodape_")) {
                            cabecalho = 0;
                            String id = n.getId().substring(n.getId().indexOf("_") + 1);
                            for (Comando d : getComandos()) {
                                if (findComando(id, d) == null) {
                                } else {
                                    parent = d;
                                    //System.out.println(parent.getType() + " " + parent.getId());
                                    parent.position = parent.getList().size();
                                    //System.out.println("posiçãoooo: " + d.position);
                                    break;
                                }
                            }
                        } else {

                            for (Comando d : getComandos()) {
                                if (n.getId() == d.getId()) {
                                    parent = null;
                                    position = getComandos().indexOf(d);
                                    break;
                                } else {
                                    String id = n.getId().toString();
                                    if (findParent(id, d) == null) {

                                    } else {
                                        break;
                                    }
                                }
                            }
                        }

                        counter++;
                        if (counter == 2) {
                            counter = 0;
                            break;
                        }

                    } else {
                        position = getComandos().size();
                    }
                }

                //System.out.println(parent);
                mDragOverIcon.setVisible(
                        false);

                //Create node drag operation
                DragContainer container
                        = (DragContainer) event.getDragboard().getContent(DragContainer.AddNode);

                if (container
                        != null) {
                    if (container.getValue("scene_coords") != null) {

                        DraggableNode node = new DraggableNode(RootLayout.this);
                        DraggableNode target = null;

                        node.setType(DragIconType.valueOf(container.getValue("type")));
                        node.setTextColor(DragIconType.valueOf(container.getValue("type")));

                        if (!container.getValue("type").equals("elsee")) {
                            verificaTipo(node, null, false);
                        } else {
                            //System.out.println("É ELSE");
                            DraggableNode node2 = new DraggableNode(RootLayout.this);
                            node2.setType(DragIconType.valueOf(container.getValue("type")));
                            node2.setTextColor(DragIconType.valueOf(container.getValue("type")));

                            verificaTipo(node2, null, true);

                            verificaTipo(node, node2.getId(), false);

                            for (Comando d : getComandos()) {
                                if (retornaComando(node2.getId(), d) == null) {
                                } else {
                                    break;
                                }
                            }

                            System.out.println(command.getId() + " " + command.isElse + " " + command.comandoAtrelado);

                            for (Comando d : getComandos()) {
                                if (retornaComando(node.getId(), d) == null) {
                                } else {
                                    break;
                                }
                            }

                            System.out.println(command.getId() + " " + command.isElse + " " + command.comandoAtrelado);
                        }

                        parent = null;
                        update();

                    }
                }
            }
        }
        );
    }

}
