/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

/**
 *
 * @author Kanan
 */
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

public class codigoGerado implements Initializable {

    @FXML
    TextArea areaCodigo;
    @FXML
    Button salvarCodigo;
    @FXML
    Button salvarImagem;

    private RootLayout layout;

    public codigoGerado(RootLayout layout) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/codigoGerado.fxml"));

            fxmlLoader.setController(this);

            this.layout = layout;

            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();

            //this.layout = layout;
            stage.setTitle("Código Gerado");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Failed to create new Window.", e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Stage stage = new Stage();
        /*
        salvarCodigo.setOnMouseClicked((event) -> {

        });
        /*
        /*
        salvarImagem.setOnMouseClicked((event) -> {
            WritableImage snapshot = layout.structure_pane.snapshot(new SnapshotParameters(), null);
            saveImage(snapshot);
        });*/

        salvarCodigo.setOnAction((ActionEvent event) -> {
            FileChooser fileChooser = new FileChooser();

            //Set extension filter
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Arquivos RTF (*.rtf)", "*.rtf");
            fileChooser.getExtensionFilters().add(extFilter);

            //Show save file dialog
            File file = fileChooser.showSaveDialog(stage);

            if (file != null) {
                SaveFile(areaCodigo.getText(), file);
            }
        });

        salvarImagem.setOnAction(new EventHandler<ActionEvent>() {

            WritableImage snapshot = layout.structure_pane.snapshot(new SnapshotParameters(), null);

            @Override
            public void handle(ActionEvent event) {

                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Salvar Imagem");

                //Set extension filter
                FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Arquivos .png (*.png)", "*.png");
                fileChooser.getExtensionFilters().add(extFilter);

                File file = fileChooser.showSaveDialog(stage);
                if (file != null) {
                    try {
                        ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);
                    } catch (IOException ex) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Erro ao salvar imagem");
                        alert.setHeaderText(null);
                        alert.setContentText("Erro ao salvar imagem!");
                        alert.showAndWait();
                    }
                }
            }
        });

    }

    /*
    private void saveImage(WritableImage snapshot) {
        BufferedImage bufferedImage = new BufferedImage(550, 400, BufferedImage.TYPE_INT_ARGB);
        File file = new File("C:/Users/Kanan/Desktop/test.jpg");
        BufferedImage image;
        image = javafx.embed.swing.SwingFXUtils.fromFXImage(snapshot, bufferedImage);
        try {
            Graphics2D gd = (Graphics2D) image.getGraphics();
            gd.translate(layout.structure_pane.getWidth(), layout.structure_pane.getHeight());
            ImageIO.write(image, "png", file);
        } catch (IOException ex) {
            //Logger.getLogger(TrySnapshot.class.getName()).log(Level.SEVERE, null, ex);
        };
    }
     */
    private void SaveFile(String content, File file) {
        try {
            FileWriter fileWriter;

            fileWriter = new FileWriter(file);
            fileWriter.write(content);
            fileWriter.close();
        } catch (IOException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Erro ao salvar arquivo");
            alert.setHeaderText(null);
            alert.setContentText("Erro ao salvar arquivo!");
            alert.showAndWait();
        }
    }

    public void atualizaCodigo() {
        areaCodigo.setText("teste");
    }

}
