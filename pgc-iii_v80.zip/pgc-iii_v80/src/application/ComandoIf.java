/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import com.singularsys.jep.EvaluationException;
import com.singularsys.jep.Jep;
import com.singularsys.jep.*;
import com.singularsys.jep.ParseException;
import com.singularsys.jep.standard.StandardVariableTable;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import org.matheclipse.core.eval.ExprEvaluator;
import org.matheclipse.core.interfaces.IExpr;

/**
 *
 * @author isidro
 */
public class ComandoIf extends Comando {

    /**
     * @return the node
     */
    public DraggableNode getNode() {
        return node;
    }

    /**
     * @param node the node to set
     */
    public void setNode(DraggableNode node) {
        this.node = node;
    }

    public String getType() {
        return type.toString();
    }

    /**
     * @return the estruturas
     */
    public ArrayList<Rectangle> getEstruturas() {
        return estruturas;
    }

    /**
     * @param estruturas the estruturas to set
     */
    public void setEstruturas(ArrayList<Rectangle> estruturas) {
        this.estruturas = estruturas;
    }

    /**
     * @return the commandList
     */
    public ArrayList<Comando> getCommandList() {
        return commandList;
    }

    /**
     * @param commandList the commandList to set
     */
    public void setCommandList(ArrayList<Comando> commandList) {
        this.commandList = commandList;
    }

    /**
     * @param type the type to set
     */
    public void setType(DragIconType type) {
        this.type = type;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    public String getId(DraggableNode n) {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    private int x;
    private int y;
    private int altura;
    private int largura;
    private String texto;
    private String tipo;
    private String id;
    private DragIconType type;
    private AnchorPane pane;
    private DraggableNode node;
    private RootLayout layout;
    private ArrayList<Rectangle> estruturas;
    private ArrayList<Comando> commandList;

    String resultado;

    String ifEXP = "";

    private Jep jep;

    public ComandoIf(AnchorPane pane, DraggableNode node, RootLayout layout, String comandoAtrelado, boolean isElse) {
        try {
            this.pane = pane;
            this.node = node;
            this.id = node.getId();
            this.type = node.getType();
            this.altura = (int) node.getAltura();
            this.largura = (int) node.getLargura();
            this.comandoAtrelado = comandoAtrelado;
            this.isElse = isElse;
            this.layout = layout;
            setCommandList(new ArrayList<Comando>());

            jep = new Jep();

            //this.texto = texto;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public ArrayList<Comando> getList() {
        return getCommandList();
    }

    @Override
    public void setList(ArrayList<Comando> list) {
        setCommandList(list);
    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @return the altura
     */
    public int getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }

    /**
     * @return the largura
     */
    public int getLargura() {
        return largura;
    }

    /**
     * @param largura the largura to set
     */
    public void setLargura(int largura) {
        this.largura = largura;
    }

    public boolean isClicked(int x, int y) {
        return (x >= x && x <= x + getLargura() && y >= y && y <= y + getAltura());
    }

    /**
     * @return the texto
     */
    public String getTexto() {
        return texto;
    }

    /**
     * @param texto the texto to set
     */
    public void setTexto(String texto) {
        this.texto = texto;
    }

    public void validar() {
        ifEXP = layout.ifExpression.getText();
        node.commandLine.setText(writeCode().toString());
    }

    public void run() {
        try {
            if (updateResult(ifEXP).equalsIgnoreCase("true")) {
                for (Comando c : getList()) {
                    c.run();
                }
            }
        } catch (EvaluationException ex) {
            Logger.getLogger(ComandoIf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private String updateResult(String exp) throws EvaluationException {
        Object result = null;
        int aux;
        String valor = null;

        jep.setComponent(new StandardVariableTable(jep.getVariableFactory()));
        // add the x variable
        // try parsing
        try {
            for (Map.Entry<String, String> entry : layout.auxMap.entrySet()) {
                //x = Double.parseDouble(entry.getKey());
                jep.addVariable(entry.getKey(), Double.parseDouble(entry.getValue()));
            }
            System.out.println("parser OK");
        } catch (Exception e) {
            System.out.println("Errooooo!!!");
        }
        try {
            jep.parse(exp);
        } catch (ParseException ex) {
            Logger.getLogger(ComandoAtrArithInput.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Get the value
        try {
            result = jep.evaluate();

            valor = result.toString();
            int i = valor.length();

            if (valor.endsWith(".0")) {
                valor = valor.substring(0, i - 2);
            }

        } catch (EvaluationException e) {
            // Clear the result and print the error message
            System.out.println("");
            System.out.println("Error while evaluating:\n" + e.getMessage());
        }
        return valor;
    }

    public String checkIf(String exp) throws IllegalArgumentException {
        try {
            //expression = exp;

            if (exp.equalsIgnoreCase("")) {
                throw new IllegalArgumentException();
            }

            StringBuilder newSentence = new StringBuilder();

            //List<String> operatorList = new ArrayList<String>();
            //List<String> operandList = new ArrayList<String>();
            StringTokenizer st = new StringTokenizer(exp, "+-*/)(<>=! ", true);

            while (st.hasMoreTokens()) {
                String token = st.nextToken();

                if ("+-/*)(<>=! ".contains(token)) {
                    newSentence.append(token);
                } else {
                    if (!layout.auxMap.containsKey(token)) {
                        newSentence.append(token);
                    } else {
                        layout.auxMap.forEach((key, value) -> {
                            if (key.equalsIgnoreCase(token)) {
                                newSentence.append(value);
                            }
                        });
                    }
                }
            }

            //System.out.println(newSentence.toString());
            //System.out.println("Operators:" + operatorList);
            //System.out.println("Operands:" + operandList);
            ExprEvaluator util = new ExprEvaluator();
            IExpr result;
            result = util.evaluate(newSentence.toString());

            //ifEXP = obj.toString();
            return result.toString();
        } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Erro de lógica");
            alert.setHeaderText(null);
            alert.setContentText("Digite uma expressão válida");
            alert.showAndWait();
        }
        return null;
    }

    public StringBuilder writeCode() {
        StringBuilder code = new StringBuilder();

        code.append("if (");
        code.append(ifEXP);
        code.append(") {");

        return code;
    }

    public int getTamanhoColuna() {
        return (altura * 50) + (coluna + 1) * 130;

        /*if (getList().size() == 0)
            return 120;
        else {
            return (altura * 50) + 130;*/
        //} /*+ ((coluna + 1) * 130);*/
    }

    public int getAltura(Comando comando) {
        int count = 0;
        if (comando.getList() == null) {
            count++;
        } else {
            count++;
            for (Comando child : comando.getList()) {
                // Now show the child's children.
                count += getAltura(child);
            }
        }
        return count;
    }

    public int ajustaColuna(Comando comando) {
        int i = 0;
        if (comando.getList() == null) {
        } else if ((comando.getType().toString() == "condition") || (comando.getType().toString() == "elsee") || (comando.getType().toString() == "loop")) {
            i++;
            for (Comando child : comando.getList()) {
                // Now show the child's children.
                i += ajustaColuna(child);
            }
        }
        //System.out.println("total de if's descendentes do nó " + node.getId() + ": " + i);
        return i;
    }

    @Override
    public Point2dSerial draw(double x, double y/*, ArrayList<Comando> commandList*/) {
        Point2dSerial coordenada = new Point2dSerial(x + 25, y + 75);
        pane.getChildren().add(getNode());
        getNode().relocateToPoint(new Point2dSerial(x, y));
        getNode().setX(getNode().getLayoutX());
        getNode().setY(getNode().getLayoutY());

        //setList(commandList);
        altura = 0;
        coluna = 0;

        for (Comando c : getList()) {
            coordenada = c.draw(coordenada.getX(), coordenada.getY());
            altura = altura + getAltura(c);
            coluna = coluna + ajustaColuna(c);
            //System.out.println(getAltura(c));
        }

        //System.out.println("Total de if's descendentes do nó " + node.getId() + ": " + coluna);
        //System.out.println("Altura do comando " + node.getId() + ": " + altura);
        //System.out.println();
        //coluna = 0;
        setEstruturas(new ArrayList<Rectangle>());

        Estrutura cabecalho = new Estrutura(pane, getEstruturas(), Color.BLUE, (int) x - 182 + 75, (int) y + 50, 350, 25, "cabecalho_" + getNode().getId(), getNode());
        Estrutura coluna = new Estrutura(pane, getEstruturas(), Color.BLUE, (int) x - 182 + 75, (int) y + 50, 25, getTamanhoColuna(), "coluna_" + getNode().getId(), getNode());
        Estrutura rodape = new Estrutura(pane, getEstruturas(), Color.BLUE, (int) x - 182 + 75, (int) coordenada.getY() + 80, 350, 25, "rodape_" + getNode().getId(), getNode());

        getNode().observer.carregar();
        return new Point2dSerial(coordenada.getX() - 25, coordenada.getY() + 105);
    }

    @Override
    public String getValor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getTipo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValor(String valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
