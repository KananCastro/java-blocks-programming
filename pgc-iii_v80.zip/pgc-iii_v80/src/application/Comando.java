/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import java.util.ArrayList;
import javafx.scene.layout.AnchorPane;

public abstract class Comando {

    /**
     * @return the parent
     */
    public Comando getParent() {
        return parent;
    }

    public String getNome() {
        return nome;
    }

    /**
     * @param parent the parent to set
     */
    public void setParent(Comando parent) {
        this.parent = parent;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    int position, altura, coluna;
    private Comando parent;
    String aux;
    String tipo;
    String comandoAtrelado;
    String nome;
    boolean isElse = false;
    boolean evaluated = false;

    public abstract Point2dSerial draw(double x, double y);

    public abstract void run();

    public abstract StringBuilder writeCode();

    public abstract String getId();

    public abstract void setId(String id);

    public abstract String getType();

    //public abstract String getVar();
    public abstract ArrayList<Comando> getList();

    public abstract void setList(ArrayList<Comando> list);

    public abstract DraggableNode getNode();

    public abstract void validar();

    public abstract String getValor();

    public abstract String getTipo();

    public abstract void setValor(String valor);
    //public abstract int getAltura();

}
