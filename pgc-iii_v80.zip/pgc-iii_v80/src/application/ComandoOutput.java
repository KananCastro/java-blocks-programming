/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import com.singularsys.jep.EvaluationException;
import com.singularsys.jep.Jep;
import com.singularsys.jep.ParseException;
import com.singularsys.jep.standard.StandardVariableTable;
import com.singularsys.jep.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

/**
 *
 * @author isidro
 */
public class ComandoOutput extends Comando {

    /**
     * @return the var
     */
    public String getVar() {
        return var;
    }

    /**
     * @param var the var to set
     */
    public void setVar(String var) {
        this.var = var;
    }

    /**
     * @return the node
     */
    public DraggableNode getNode() {
        return node;
    }

    /**
     * @param node the node to set
     */
    public void setNode(DraggableNode node) {
        this.node = node;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type.toString();
    }

    /**
     * @param type the type to set
     */
    public void setType(DragIconType type) {
        this.type = type;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    public String getId(DraggableNode n) {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    private int x;
    private int y;
    private int altura;
    private int largura;
    private String texto;
    private DragIconType type;
    private String id;
    private String tipo;
    private AnchorPane pane;
    private DraggableNode node;
    private RootLayout layout;

    private boolean hasVar;

    private Jep jep;

    public String exp = "";
    public String data = "";
    private String var = "";

    public ComandoOutput(AnchorPane pane, DraggableNode node, RootLayout layout, String comandoAtrelado, boolean isElse) {
        try {
            this.pane = pane;
            this.node = node;
            this.id = node.getId();
            this.type = node.getType();
            this.altura = (int) node.getAltura();
            this.largura = (int) node.getLargura();
            this.comandoAtrelado = comandoAtrelado;
            this.layout = layout;
            this.isElse = isElse;

            jep = new Jep();
            //this.texto = texto;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void updateResult() throws EvaluationException {
        if (hasVar == true) {
            Object result = null;
            int aux;
            String valor;

            String temp = var;

            jep.setComponent(new StandardVariableTable(jep.getVariableFactory()));
            // add the x variable
            // try parsing
            try {
                for (Map.Entry<String, String> entry : layout.auxMap.entrySet()) {
                    //x = Double.parseDouble(entry.getKey());
                    jep.addVariable(entry.getKey(), Double.parseDouble(entry.getValue()));
                }
                System.out.println("parser OK");
            } catch (Exception e) {
                System.out.println("Errooooo!!!");
            }
            try {
                jep.parse(var);
            } catch (ParseException ex) {
                Logger.getLogger(ComandoAtrArithInput.class.getName()).log(Level.SEVERE, null, ex);
            }

            // Get the value
            try {
                result = jep.evaluate();

                valor = result.toString();
                int i = valor.length();

                if (valor.endsWith(".0")) {
                    valor = valor.substring(0, i - 2);
                }

                data = valor;

            } catch (EvaluationException e) {
                // Clear the result and print the error message
                System.out.println("");
                System.out.println("Error while evaluating:\n" + e.getMessage());
            }
        }
    }

    public void run() {

        try {
            /*for (Map.Entry<String, List<String>> entry : layout.runMap.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();

            if (values.get(0).equalsIgnoreCase(var)) {
            data = values.get(2);
            break;
            }
            }*/

            updateResult();
        } catch (EvaluationException ex) {
            Logger.getLogger(ComandoOutput.class.getName()).log(Level.SEVERE, null, ex);
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Output");
        alert.setHeaderText(null);
        alert.setContentText(exp + " " + data);
        alert.showAndWait();

    }

    public void validar() {

        exp = layout.outputTexto.getText();

        if (layout.outputVar.getText().equals("")) {
            //System.out.println("erro");
            hasVar = false;
        } else {
            setVar(layout.outputVar.getText());
            hasVar = true;
            //System.out.println(var);
        }

        node.commandLine.setText(writeCode().toString());
    }

    @Override
    public ArrayList<Comando> getList() {
        return null;
    }

    @Override
    public void setList(ArrayList<Comando> list) {

    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @return the altura
     */
    public int getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }

    /**
     * @return the largura
     */
    public int getLargura() {
        return largura;
    }

    /**
     * @param largura the largura to set
     */
    public void setLargura(int largura) {
        this.largura = largura;
    }

    public boolean isClicked(int x, int y) {
        return (x >= x && x <= x + getLargura() && y >= y && y <= y + getAltura());
    }

    /**
     * @return the texto
     */
    public String getTexto() {
        return texto;
    }

    /**
     * @param texto the texto to set
     */
    public void setTexto(String texto) {
        this.texto = texto;
    }

    public StringBuilder writeCode() {
        StringBuilder code = new StringBuilder();

        //code.append("System.out.println(");
        code.append("JOptionPane.showMessageDialog(null, ");

        if (exp.equalsIgnoreCase("")) {
            code.append(getVar());
            code.append(");");

        } else {
            code.append("\"" + exp);

            if (getVar().equalsIgnoreCase("")) {
                code.append("\");");
            } else {
                code.append("\" + ");
                code.append(getVar());
                code.append(");");
            }

        }

        return code;
    }

    @Override
    public Point2dSerial draw(double x, double y) {
        pane.getChildren().add(getNode());
        getNode().relocateToPoint(new Point2dSerial(x, y));
        getNode().setX(getNode().getLayoutX());
        getNode().setY(getNode().getLayoutY());
        getNode().observer.carregar();
        return new Point2dSerial(x, y + 50);
    }

    @Override
    public String getValor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getTipo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValor(String valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
