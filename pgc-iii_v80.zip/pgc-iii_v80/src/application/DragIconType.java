package application;

public enum DragIconType {
	input,	
	atrArithInput,
	condition,
        elsee,
	loop,
	output
}
