/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import com.singularsys.jep.EvaluationException;
import com.singularsys.jep.Jep;
import com.singularsys.jep.ParseException;
import com.singularsys.jep.standard.StandardVariableTable;
import com.singularsys.jep.functions.Modulus;
import com.singularsys.jep.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import org.matheclipse.core.eval.ExprEvaluator;
import org.matheclipse.core.interfaces.IExpr;

/**
 *
 * @author isidro
 */
public class ComandoAtrArithInput extends Comando {

    /**
     * @return the node
     */
    public DraggableNode getNode() {
        return node;
    }

    /**
     * @param node the node to set
     */
    public void setNode(DraggableNode node) {
        this.node = node;
    }

    /**
     * @return the type
     */
    public String getType() {
        return tipo.toString();
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    public String getId(DraggableNode n) {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    private int x;
    private int y;
    private int altura;
    private int largura;
    private String texto;
    private DragIconType tipo;
    private String id;
    private String type;
    private AnchorPane pane;
    private DraggableNode node;
    private RootLayout layout;

    private Jep jep;

    String tipoObtido = "";
    String tipoDigitado = "";

    String writeCodeOriginal = "";
    String writeCodeResult = "";

    private String atrVar = "";
    private String expression = "";

    String valor = "";
    
    String strAux = "";

    String idAtualiza;

    public ComandoAtrArithInput(AnchorPane pane, DraggableNode node, RootLayout layout, String comandoAtrelado, boolean isElse) {
        try {
            this.pane = pane;
            this.node = node;
            this.id = node.getId();
            this.tipo = node.getType();
            this.altura = (int) node.getAltura();
            this.largura = (int) node.getLargura();
            this.comandoAtrelado = comandoAtrelado;
            this.isElse = isElse;
            this.layout = layout;

            jep = new Jep();
            //this.texto = texto;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void run() {

        if (expression.equalsIgnoreCase("input")) {
            Dialog dialog = new Dialog<>();
            dialog.setTitle("Teclado");
            dialog.setHeaderText(null);

            ButtonType validar = new ButtonType("Validar");
            dialog.getDialogPane().getButtonTypes().addAll(validar);

            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(20, 150, 10, 10));

            TextField Atr_Expression = new TextField();
            Atr_Expression.setText("");

            grid.add(new Label("Digite um valor ou uma expressão para " + atrVar + ":"), 0, 0);
            grid.add(Atr_Expression, 0, 1);

            dialog.getDialogPane().setContent(grid);

            Optional<ButtonType> result = dialog.showAndWait();

            ButtonType button = result.orElse(ButtonType.CANCEL);

            if (button == validar) {
                expression = Atr_Expression.getText();
                atributeValue();
                expression = "input";
            } else {

            }
        } else {
            atributeValue();
        }

    }

    public void validar() {
        if (atrVar.equalsIgnoreCase("")) {
            atrVar = layout.Atr_Var.getSelectionModel().getSelectedItem().toString();
        } else {

        }
        expression = layout.Atr_Expression.getText();
        strAux = expression;
        if (expression.equalsIgnoreCase("input")) {
            node.commandLine.setText(atrVar + "= input;");
        } else {
            node.commandLine.setText(writeCode().toString());
        }
    }

    private void updateResult() {
        Object result = null;
        int aux;

        // Get the value
        try {
            result = jep.evaluate();

            // Is the result ok?
            if (result != null) {
                System.out.println(result.toString());
                layout.auxMap.put(atrVar, result.toString());
                for (Comando d : layout.getComandos()) {
                    if (layout.retornaComando(atrVar, d) == null) {
                    } else {
                        break;
                    }
                }
                valor = result.toString();
                int i = valor.length();
                
                if (valor.endsWith(".0")){
                    valor = valor.substring(0, i-2);
                }
                
                //valor = valor.substring(0, i);
                layout.atualizaValor(atrVar, valor);
                layout.auxMap.put(atrVar, valor);
            } else {
                //System.out.println("null");
            }
            
            
            System.out.println("");
        } catch (EvaluationException e) {
            // Clear the result and print the error message
            System.out.println("");
            System.out.println("Error while evaluating:\n" + e.getMessage());
            valor = strAux;

            //valor = valor.substring(0, i);
            layout.atualizaValor(atrVar, valor);
            layout.auxMap.put(atrVar, valor);

        }
    }

    public void atributeValue() {
        /*
        String varEscolhida = var;

        atrVar = varEscolhida;

        writeCodeOriginal = varEscolhida + " = " + obj.toString();
         */

        String temp = expression;

        int i = expression.length();

        jep.setComponent(new StandardVariableTable(jep.getVariableFactory()));
        // add the x variable
        // try parsing
        try {
            for (Map.Entry<String, String> entry : layout.auxMap.entrySet()) {
                //x = Double.parseDouble(entry.getKey());
                jep.addVariable(entry.getKey(), Double.parseDouble(entry.getValue()));
            }
            System.out.println("parser OK");
        } catch (Exception e) {
            System.out.println("Errooooo!!!");
        }
        try {
            jep.parse(expression);
            updateResult();
        } catch (ParseException ex) {
            Logger.getLogger(ComandoAtrArithInput.class.getName()).log(Level.SEVERE, null, ex);
        }

        /*
            if (temp.equals("")) {
            throw new IllegalArgumentException();
            }
         */
 /* PARTE PARA SE CHECAR O TIPO PARA POSTERIOR VALIDAÇÃO (NÃO MISTURAR INTEGER COM DOUBLE)
            layout.runMap.forEach((key, value) -> {
            if (value.equalsIgnoreCase(layout.Atr_Var.getSelectionModel().getSelectedItem().toString())) {
            //System.out.println(key + " " + value);
            for (Comando d : layout.getComandos()) {
            if (layout.retornaComando(key, d) == null) {
            } else {
            break;
            }
            }
            tipoObtido = layout.command.getTipo();
            }
            });
         */
 
    }

    @Override
    public StringBuilder writeCode() {
        StringBuilder code = new StringBuilder();
        if (expression.equalsIgnoreCase("input")) {
            code.append(atrVar + " = JOptionPane.showInputDialog(\"Digite um valor ou uma expressão para " + atrVar + ":\");");
        } else {
            code.append(atrVar + " = " + expression + ";");
        }
        return code;
    }

    @Override
    public ArrayList<Comando> getList() {
        return null;
    }

    @Override
    public void setList(ArrayList<Comando> list) {

    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @return the altura
     */
    public int getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }

    /**
     * @return the largura
     */
    public int getLargura() {
        return largura;
    }

    /**
     * @param largura the largura to set
     */
    public void setLargura(int largura) {
        this.largura = largura;
    }

    public boolean isClicked(int x, int y) {
        return (x >= x && x <= x + getLargura() && y >= y && y <= y + getAltura());
    }

    /**
     * @return the texto
     */
    public String getTexto() {
        return texto;
    }

    /**
     * @param texto the texto to set
     */
    public void setTexto(String texto) {
        this.texto = texto;
    }

    @Override
    public Point2dSerial draw(double x, double y) {
        pane.getChildren().add(getNode());
        getNode().relocateToPoint(new Point2dSerial(x, y));
        getNode().setX(getNode().getLayoutX());
        getNode().setY(getNode().getLayoutY());
        getNode().observer.carregar();
        return new Point2dSerial(x, y + 50);
    }

    @Override
    public String getValor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getTipo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValor(String valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
