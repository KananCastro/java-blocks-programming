/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.lang.Double;
import java.lang.IllegalArgumentException;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import javafx.geometry.Insets;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 *
 * @author isidro
 */
public class ComandoAlocVar extends Comando {

    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(String valor) {
        this.valor = valor;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the node
     */
    public DraggableNode getNode() {
        return node;
    }

    /**
     * @param node the node to set
     */
    public void setNode(DraggableNode node) {
        this.node = node;
    }

    /**
     * @return the tipo
     */
    public String getType() {
        return type.toString();
    }

    /**
     * @param type the tipo to set
     */
    public void setType(DragIconType type) {
        this.type = type;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    public String getId(DraggableNode n) {
        return id;
    }

    /**
     * @param id the id to set
     */
    @Override
    public void setId(String id) {
        this.id = id;
    }

    private int x;
    private int y;
    private int altura;
    private int largura;
    private String nome;
    private String valor;
    private String tipo;
    private DragIconType type;
    private String id;
    private AnchorPane pane;
    private DraggableNode node;
    private RootLayout layout;
    private String stringValor = "";

    public ComandoAlocVar(AnchorPane pane, DraggableNode node, RootLayout layout, String comandoAtrelado, boolean isElse) {
        try {
            this.layout = layout;
            this.pane = pane;
            this.node = node;
            this.id = node.getId();
            this.type = node.getType();
            this.altura = (int) node.getAltura();
            this.largura = (int) node.getLargura();
            this.valor = "";
            this.nome = "";
            this.tipo = "";
            this.comandoAtrelado = comandoAtrelado;
            this.isElse = isElse;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public ArrayList<Comando> getList() {
        return null;
    }

    @Override
    public void setList(ArrayList<Comando> list) {

    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @return the altura
     */
    public int getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }

    /**
     * @return the largura
     */
    public int getLargura() {
        return largura;
    }

    /**
     * @param largura the largura to set
     */
    public void setLargura(int largura) {
        this.largura = largura;
    }

    public boolean isClicked(int x, int y) {
        return (x >= x && x <= x + getLargura() && y >= y && y <= y + getAltura());
    }

    /**
     * @return the valor
     */
    public String getTexto() {
        return getValor();
    }

    /**
     * @param texto the valor to set
     */
    public void setTexto(String texto) {
        this.setValor(texto);
    }

    public StringBuilder writeCode() {
        StringBuilder code = new StringBuilder();
        code.append(tipo + " " + nome + ";");
        return code;
    }

    public void run() {
        List<String> list = new ArrayList<String>();
        list.add(nome);
        list.add(tipo);
        list.add(valor);

        layout.runMap.put(id, list);
    }

    public void validar() {
        String tipoEscolhido = layout.inputTipo.getSelectionModel().getSelectedItem().toString();

        if (tipoEscolhido.equalsIgnoreCase("Integer")) {
            setTipo("int");
        } else if (tipoEscolhido.matches("Double")) {
            setTipo("double");
        } else {
            setTipo("String");
        }

        setNome(layout.inputNome.getText());
        setValor(null);

        node.commandLine.setText(writeCode().toString());

        List<String> list = new ArrayList<String>();
        list.add(nome);
        list.add(tipo);
        list.add(valor);

        layout.compilerMap.put(id, list);
        layout.auxMap.put(nome, valor);
    }

    @Override
    public Point2dSerial draw(double x, double y) {
        pane.getChildren().add(getNode());
        getNode().relocateToPoint(new Point2dSerial(x, y));
        getNode().setX(getNode().getLayoutX());
        getNode().setY(getNode().getLayoutY());
        getNode().observer.carregar();
        return new Point2dSerial(x, y + 50);
    }

}
