package application;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.UUID;
import java.util.Collections;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.Circle;
import javax.imageio.ImageIO;
import application.RootLayout;
import java.io.PrintStream;
import javafx.geometry.Bounds;
import javafx.scene.Cursor;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import application.RootLayout;
import java.util.Map;
import java.util.Map.Entry;
import javafx.scene.control.Alert;
import javafx.scene.layout.StackPane;
import javax.swing.DefaultComboBoxModel;

public class DraggableNode extends AnchorPane {

    /**
     * @return the num
     */
    public Integer getNum() {
        return num;
    }

    /**
     * @param num the num to set
     */
    public void setNum(Integer num) {
        this.num = num;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(String valor) {
        this.valor = valor;
    }

    /**
     * @param x the x to set
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * @param y the y to set
     */
    public void setY(double y) {
        this.y = y;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * @param largura the largura to set
     */
    public void setLargura(double largura) {
        this.largura = largura;
    }

    /**
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * @return the y
     */
    public double getY() {
        return y;
    }

    /**
     * @return the altura
     */
    public double getAltura() {
        return 50;
    }

    /**
     * @return the largura
     */
    public double getLargura() {
        return 300;
    }

    @FXML
    private AnchorPane root_pane;
    @FXML
    private Label title_bar;
    @FXML
    private Label close_button;
    @FXML
    Label commandLine;
    @FXML
    ImageView lixeira;

    //StackPane centeredPane;
    private double x;
    private double y;
    private double altura;
    private double largura;

    DraggableNode target = null;

    Observer observer;

    Bounds objA;

    private String tipo;
    private String nome;
    private String valor;
    int num;

    private EventHandler<DragEvent> mContextDragOver;
    private EventHandler<DragEvent> mContextDragDropped;
    private EventHandler<DragEvent> mContextDragOverRoot;

    DragIconType mType = null;

    Point2D mDragOffset = new Point2D(0.0, 0.0);

    private final DraggableNode self;

    private AnchorPane right_pane, pane = null;

    private RootLayout layout;

    private final List<String> mLinkIds = new ArrayList<String>();

    public DraggableNode(RootLayout rootPane) {
        observer = new Observer(this, rootPane);
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getResource("/DraggableNode.fxml")
        );

        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        self = this;
        pane = rootPane;
        layout = rootPane;

        try {
            fxmlLoader.load();

        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        //provide a universally unique identifier for this object
        setId(UUID.randomUUID().toString());

        self.setNum(rootPane.getFlag());
        //System.out.println(num);
        //num++;

        this.lixeira = rootPane.lixeira;

        objA = lixeira.localToScene(lixeira.getBoundsInLocal());
        //objA = rootPane.centeredPane.localToScene(lixeira.getBoundsInLocal());

        self.setTipo("DEFINIR TIPO");
        self.setNome("DEFINIR NOME");
        self.setValor("DEFINIR VALOR");

    }

    @FXML
    private void initialize() throws Exception {

        buildNodeDragHandlers();

        parentProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue observable,
                    Object oldValue, Object newValue) {
                right_pane = (AnchorPane) getParent();

            }

        });
    }

    public void registerLink(String linkId) {
        mLinkIds.add(linkId);
    }

    public void setTextColor(DragIconType type) {

        mType = type;
        switch (mType) {

            case input:
                commandLine.setTextFill(Color.BLACK);
                break;

            case loop:
                commandLine.setTextFill(Color.WHITE);
                break;

            case atrArithInput:
                commandLine.setTextFill(Color.BLACK);
                break;

            case condition:
                commandLine.setTextFill(Color.YELLOW);
                break;

            case elsee:
                commandLine.setTextFill(Color.YELLOW);
                break;

            case output:
                commandLine.setTextFill(Color.BLACK);
                break;

            default:
                break;
        }
    }

    public void relocateToPoint(Point2D p) {

        //relocates the object to a point that has been converted to
        //scene coordinates
        Point2D localCoords = getParent().sceneToLocal(p);

        relocate(
                (int) (localCoords.getX() - mDragOffset.getX()),
                (int) (localCoords.getY() - mDragOffset.getY())
        );
    }

    public DragIconType getType() {
        return mType;
    }

    public void setType(DragIconType type) {

        mType = type;

        getStyleClass().clear();
        getStyleClass().add("dragicon");

        switch (mType) {

            case input:
                getStyleClass().remove("input");
                getStyleClass().add("input2");
                break;

            case loop:
                getStyleClass().remove("loop");
                getStyleClass().add("loop2");
                break;

            case atrArithInput:
                getStyleClass().remove("atrArithInput");
                getStyleClass().add("atrArithInput2");
                break;

            case condition:
                getStyleClass().remove("condition");
                getStyleClass().add("condition2");
                break;

            case elsee:
                getStyleClass().remove("elsee");
                getStyleClass().add("elsee2");
                break;

            case output:
                getStyleClass().remove("output");
                getStyleClass().add("output2");
                break;

            default:
                break;
        }
    }

    public void excluiComando(String id, ArrayList<Comando> List) {
        for (Comando c : List) {
            if (c.getId().matches(id)) {
                List.remove(c);
                observer.update();
            } else {
                if (c.getList() == null) {

                } else {
                    excluiComando(id, c.getList());
                }
            }
        }
    }

    public Comando findComando(String id, ArrayList<Comando> List) {
        for (Comando c : List) {
            if (c.getId().matches(id)) {
                if (c.getParent() == null) {
                    //System.out.println(c.getType() + " - parent: " + c.getParent() + " - indice: " + observer.getComandos().indexOf(c));
                } else {
                    //System.out.println(c.getType() + " - parent: " + c.getParent().getId() + " - indice: " + c.getParent().getList().indexOf(c));
                }
                return c;
            } else {
                if (c.getList() == null) {

                } else {
                    findComando(id, c.getList());
                }
            }
        }
        return null;
    }

    public void buildNodeDragHandlers() throws Exception {

        mContextDragOver = new EventHandler<DragEvent>() {

            //dragover to handle node dragging in the right pane view
            @Override
            public void handle(DragEvent event) {

                event.acceptTransferModes(TransferMode.ANY);
                relocateToPoint(new Point2dSerial(event.getSceneX() - 150, event.getSceneY() - 25));

                //System.out.println(self.localToScene(self.getBoundsInLocal()));
                //System.out.println(lixeira.localToScene(lixeira.getBoundsInLocal()));
                Bounds objB = self.localToScene(self.getBoundsInLocal());

                for (Node n : right_pane.getChildren()) {
                    //target = (DraggableNode) n;
                    Bounds target;
                    target = n.localToScene(n.getBoundsInLocal());
                    if (objB.intersects(target) && getId() != n.getId()) {
                        n.setOpacity(0.3);
                    } else {
                        n.setOpacity(1);
                    }
                }

                if (objB.intersects(objA)) {
                    self.setOpacity(0.3);
                } else {
                    self.setOpacity(1);
                }

                event.consume();
            }
        };

        //dragdrop for node dragging
        mContextDragDropped = new EventHandler<DragEvent>() {

            @Override
            public void handle(DragEvent event) {

                getParent().setOnDragOver(null);
                getParent().setOnDragDropped(null);

                Bounds objB = self.localToScene(self.getBoundsInLocal());

                observer.findComandoOrigem(self.getId(), observer.getComandos());

                for (Node n : right_pane.getChildren()) {
                    //target = (DraggableNode) n;
                    Bounds target;
                    target = n.localToScene(n.getBoundsInLocal());

                    if (getId() != n.getId()) {
                        if (objB.intersects(target)) {
                            observer.findComandoDestino(n.getId(), observer.getComandos());
                            observer.changeComando();
                            System.out.println();
                        }
                    }
                }

                if (objB.intersects(objA)) {
                    String id = self.getId();

                    for (Comando d : layout.getComandos()) {
                        if (layout.retornaComando(id, d) == null) {
                        } else {
                            break;
                        }
                    }

                    if (layout.command.comandoAtrelado == null) {

                        AnchorPane parent = (AnchorPane) self.getParent();
                        parent.getChildren().remove(self);

                        excluiComando(id, observer.getComandos());

                        observer.update();

                    } else {

                        String id2 = layout.command.comandoAtrelado;

                        AnchorPane parent = (AnchorPane) self.getParent();
                        parent.getChildren().remove(self);

                        excluiComando(id, observer.getComandos());

                        parent.getChildren().remove(id2);
                        excluiComando(id2, observer.getComandos());

                        observer.update();

                    }

                } else {

                    observer.update();

                }

                //System.out.println("X: " + self.getX() + ", Y: " + self.getY());
                //observer.carregar();
                event.setDropCompleted(true);
                event.consume();
            }

        };

        self.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                observer.carregar();
                observer.habilitaMenu(self);

                if (self.getType().toString().equals("atrArithInput")) {
                    //System.out.println("OK");
                    layout.Atr_Var.getItems().clear();

                    for (Entry<String, List<String>> entry : layout.compilerMap.entrySet()) {
                        String key = entry.getKey();
                        List<String> values = entry.getValue();
                        //System.out.println(values.get(2));
                        layout.Atr_Var.getItems().add(values.get(0));
                    }
                }

                if (self.getType().toString().equals("output")) {
                    //System.out.println("OK");
                    layout.outputVar.setText("");

                    /*for (Entry<String, List<String>> entry : layout.compilerMap.entrySet()) {
                        String key = entry.getKey();
                        List<String> values = entry.getValue();
                        //System.out.println(values.get(2));
                        layout.outputVar.getItems().add(values.get(0));
                    }*/
                }

                if (self.getType().toString().equals("loop")) {
                    //System.out.println("OK");
                    layout.varFor.getItems().clear();

                    for (Entry<String, List<String>> entry : layout.compilerMap.entrySet()) {
                        String key = entry.getKey();
                        List<String> values = entry.getValue();
                        //System.out.println(values.get(2));
                        layout.varFor.getItems().add(values.get(0));
                    }
                }

                if (self.getType().toString().equals("input")) {
                    System.out.println(layout.getComando(self).getValor());
                    System.out.println(self.getId());
                }

            }
        });

        //drag detection for node dragging
        self.setOnDragDetected(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                //System.out.println("self: " + self.getY() + ", Y_Cursor: " + observer.getY_Cursor());

                getParent().setOnDragOver(null);
                getParent().setOnDragDropped(null);

                getParent().setOnDragOver(mContextDragOver);
                getParent().setOnDragDropped(mContextDragDropped);
                /*
                    //begin drag ops
                    mDragOffset = new Point2D(event.getX(), event.getY());

                    relocateToPoint(
                            new Point2D(event.getSceneX(), event.getSceneY())
                    );
                 */
                ClipboardContent content = new ClipboardContent();
                DragContainer container = new DragContainer();

                container.addData("type", mType.toString());
                content.put(DragContainer.AddNode, container);

                //pass the UUID of the source node for later lookup
                container.addData("source", getId());

                startDragAndDrop(TransferMode.ANY).setContent(content);

            }

        });

    }
}
